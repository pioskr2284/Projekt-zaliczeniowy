package com.example.demo.orders;

public enum OrderStatus {
    IN_REALIZATION,FINISHED;
}
