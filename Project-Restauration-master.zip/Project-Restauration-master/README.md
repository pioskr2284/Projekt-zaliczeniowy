# University project done in java language.
I wanted to create application in which Waiter can add restaurant orders which will be saved to in Memory Database.
Technologies that i used:
Java
Hibernate
Spring boot
H2-database
JPA Repository
